package com.springframework.saiedmadminpanel.web.factories;

import com.springframework.saiedmadminpanel.web.dto.CategoryDocumentDto;
import com.springframework.saiedmadminpanel.web.store.entities.CategoryDocumentEntity;
import org.springframework.stereotype.Component;

@Component
public class CategoryDocumentFactory {
    public CategoryDocumentDto makeCategoryDocumentDto(CategoryDocumentEntity entity){
        return CategoryDocumentDto.builder()
                .id(entity.getId())
                .name(entity.getName())
                .code(entity.getCode())
                .is_deleted(entity.getIs_deleted())
                .build();
    }
}
