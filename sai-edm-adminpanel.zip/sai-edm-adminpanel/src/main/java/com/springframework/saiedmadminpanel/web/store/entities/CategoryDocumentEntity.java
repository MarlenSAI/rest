package com.springframework.saiedmadminpanel.web.store.entities;


import lombok.*;
import lombok.experimental.FieldDefaults;
import javax.persistence.*;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "category_document")
public class CategoryDocumentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;
    @Column
    String code;
    @Column
    String name;
    @Column
    Boolean is_deleted = false;
}
