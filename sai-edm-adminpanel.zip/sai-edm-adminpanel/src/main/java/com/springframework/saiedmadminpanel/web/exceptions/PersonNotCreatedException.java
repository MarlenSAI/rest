package com.springframework.saiedmadminpanel.web.exceptions;

public class PersonNotCreatedException extends RuntimeException{
    public PersonNotCreatedException(String msg){
        super(msg);
    }
}
