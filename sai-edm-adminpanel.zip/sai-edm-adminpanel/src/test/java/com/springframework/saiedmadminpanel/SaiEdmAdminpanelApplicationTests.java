package com.springframework.saiedmadminpanel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaiEdmAdminpanelApplicationTests {

    @Test
    void contextLoads() {
    }

}
